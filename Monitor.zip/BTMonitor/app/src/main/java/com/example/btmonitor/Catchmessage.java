package com.example.btmonitor;

public interface Catchmessage {
    void sendData (String str);
}
