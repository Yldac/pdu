package com.example.btmonitor.bluetooth;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

import com.example.btmonitor.Catchmessage;
import com.example.btmonitor.MainActivity;
import com.example.btmonitor.MessageHandler;
import com.example.btmonitor.R;
import com.example.btmonitor.adapter.BtConsts;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class RecieveThread extends Thread {
    private BluetoothSocket socket;
    private InputStream inputS;
    private OutputStream outputS;
    private byte[] rBuffer;
    private String valueRead;
    //private final Catchmessage catchmessage;
    MainActivity mainActivity;
    Context context;
    private final MessageHandler mHandler;
    static final String RECEIVE_MESSAGE = "receive_message";

    public RecieveThread(BluetoothSocket socket, MessageHandler handler) {
        //this.mainActivity = mainActivity;
        this.socket = socket;
        this.mHandler = handler;
        //this.catchmessage = catchmessage;
        try {
           inputS = socket.getInputStream();
        } catch (IOException e) {}
        try {
            outputS = socket.getOutputStream();
        } catch (IOException e) {}
    }



    @SuppressLint("NewApi")
    @Override
    public void run() {
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputS));
        //rBuffer = new byte[5];
        while (true){
            try {
                String line = reader.readLine();
                if (line != null){
               // mHandler.sendLineRead(line);
                    Log.d("package:mine", "Message: "+ line);
                }
//                String message = new String(rBuffer, 0, size);
//                Log.d("package:mine", "Message: "+ message);

                //catchmessage.sendData(message);
                //mainActivity.showDefaultToast(message);
                //valueRead = message;
                //BtConsts.RECEIVE_MESSAGE = message;
            } catch (IOException ignored){}
        }
    }


//    void receiveData (){
//        catchmessage.catchData(valueRead);
//    }


    public void sendMessage (byte[] byteArray){
        try {
            outputS.write(byteArray);
        } catch (IOException ignored){}
    }
    public String getValueRead(){
        return valueRead;
    }

}
